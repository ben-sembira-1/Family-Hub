package com.example.sembi.logingui;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class FamilyMembers extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_family_members);
    }
}
