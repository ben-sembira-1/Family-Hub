package com.example.sembi.logingui;

public class MedicalRecordModel {
    private String title;
    private String content;

    public MedicalRecordModel(String title, String content) {
        this.title = title;
        this.content = content;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
