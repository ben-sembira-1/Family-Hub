package com.example.sembi.logingui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;


public class firstActivity_Login extends AppCompatActivity {

    ImageView eye;
    EditText pass;
    Boolean show;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first__login);

        eye = findViewById(R.id.eyeImageV);
        pass = findViewById(R.id.passEditT);
        show = false;
    }

    public void showPass(View view) {
        String STRpassword = pass.getText().toString();


        if (show) {
            show = !show;
            eye.setImageDrawable((getDrawable(R.drawable.eye)));
            pass.setInputType( InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
            pass.setText("");
            pass.setText(STRpassword);


        }
        else {
            show = !show;
            eye.setImageDrawable((getDrawable(R.drawable.eye_enabled)));
            pass.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            pass.setText(STRpassword);
            pass.setTextDirection(View.TEXT_DIRECTION_LTR);

        }
    }

    public void newAcount(View view){
        Intent intent = new Intent(this, newAcount.class);
        startActivity(intent);
    }

    public void logIn(View view) {
        if (logInAprooved()) {
            Intent intent = new Intent(this, homeScreen.class);
            startActivity(intent);
        }
    }

    private boolean logInAprooved() {
        //TODO check with data base
        return true;
    }
}
