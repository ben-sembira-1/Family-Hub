package com.example.sembi.logingui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class Profile extends AppCompatActivity {

    TextView phone;

    TextView[] TextDataArray;
    EditText[] EditTextDataArray;
    Button[] BottomButtonsArray;

    Button medicIDBtn;
    ImageView goToMedicBtn;
    ImageView goToHomeBtn;

    ImageView editIcon;

    static Boolean EDIT_MODE = false;

    final static int NUMBER_OF_PARAMETERS = 6;

    private static boolean firstTime = true;
    private static boolean secondTime = true;


    public static String getFullName() {
        return FULL_NAME;
    }

    private static String FULL_NAME;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        editIcon = findViewById(R.id.editImageV_Button_);

        phone = findViewById(R.id.PhoneTextV);

        //TODO:
        //firstTime = isFirstTime();

        medicIDBtn = findViewById(R.id.medicalIDBtn);
        goToMedicBtn = findViewById(R.id.moveOnButton);
        goToHomeBtn = findViewById(R.id.backHomeBtn);

        TextDataArray = new TextView[NUMBER_OF_PARAMETERS];
        EditTextDataArray = new EditText[NUMBER_OF_PARAMETERS];
        BottomButtonsArray = new Button[3];
        //initialize =>
        setBottomButtonsArray();
        setTextDataArrray();
        setEditTextDataArrray();
        refresh();

    }


    private void refresh() {
        refreshEditMode();
        refreshFirstTime();
    }

    private void refreshFirstTime() {
        //TODO
        if (firstTime || secondTime) {
            if (firstTime) {
                for (Button B : BottomButtonsArray) {
                    B.setVisibility(View.INVISIBLE);
                }
                medicIDBtn.setVisibility(View.INVISIBLE);
                goToMedicBtn.setVisibility(View.VISIBLE);
                firstTime = false;
                secondTime = true;
            } else {
                for (Button B : BottomButtonsArray) {
                    B.setVisibility(View.VISIBLE);
                }
                medicIDBtn.setVisibility(View.VISIBLE);
                goToMedicBtn.setVisibility(View.INVISIBLE);
                goToHomeBtn.setVisibility(View.VISIBLE);
                secondTime = false;
            }
        }
    }

    private boolean isFirstTime() {
        //TODO get from dataBase.
        return true;
    }

    private void setEditTextDataArrray() {
        EditText[] ET_id_s = {findViewById(R.id.editNameV),
                findViewById(R.id.editPhoneV),
                findViewById(R.id.editEmailV),
                findViewById(R.id.editBdayV),
                findViewById(R.id.editCityV),
                findViewById(R.id.editAdressV)};

        for (int i = 0; i < NUMBER_OF_PARAMETERS; i++) {
            EditTextDataArray[i] = ET_id_s[i];
        }
    }

    private void setTextDataArrray() {
        TextView[] TV_id_s = {findViewById(R.id.NameTextV),
                findViewById(R.id.PhoneTextV),
                findViewById(R.id.EmailTextV),
                findViewById(R.id.BdayTextV),
                findViewById(R.id.cityTextV),
                findViewById(R.id.AdressTextV)};

        for (int i = 0; i < NUMBER_OF_PARAMETERS; i++) {
            TextDataArray[i] = TV_id_s[i];
        }
    }

    private void setBottomButtonsArray() {
        Button[] B_id_s = {findViewById(R.id.addChildBtn),
                findViewById(R.id.addFatherdBtn),
                findViewById(R.id.addMotherBtn)};

        for (int i = 0; i < B_id_s.length; i++) {
            BottomButtonsArray[i] = B_id_s[i];
        }
    }

    public void call(View view) { //TODO it isn't working.
        String phoneNumber = phone.getText().toString();
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:" + phoneNumber));
        if (checkSelfPermission(Manifest.permission.WRITE_CALENDAR)
                == PackageManager.PERMISSION_GRANTED) {
            // Permission is granted
            startActivity(callIntent);
            phone.setText("hhhhh");
            return;
        }
        phone.setText("yyyy");

    }

    public void onOffEditMode(View view) {
        onOffEditModePrivate();
    }

    private void onOffEditModePrivate() {
        this.EDIT_MODE = !EDIT_MODE;
        refreshEditMode();
    }


    private void refreshEditMode() {
        changeVisibality();
        changeIcon();
        saveChangesInMemory();
        saveChangesInDataBase();
    }

    private void saveChangesInDataBase() {
        //TODO
    }

    private void saveChangesInMemory() {
        for (int i = 0; i < NUMBER_OF_PARAMETERS; i++) {
            TextDataArray[i].setText(EditTextDataArray[i].getText().toString());
        }
        FULL_NAME = TextDataArray[0].getText().toString();
    }

    private void changeIcon() {

        if (EDIT_MODE)
            editIcon.setImageDrawable(getDrawable(R.drawable.ic_mode_edit_on_24dp));
        else
            editIcon.setImageDrawable(getDrawable(R.drawable.ic_mode_edit_off_24dp));
    }

    private void changeVisibality() {
        int textVisibality = View.VISIBLE, editTextVisibality = View.GONE;

        if (EDIT_MODE) {
            textVisibality = View.GONE;
            editTextVisibality = View.VISIBLE;
        }

        for (EditText ET : EditTextDataArray) {
            ET.setVisibility(editTextVisibality);
        }

        for (EditText ET : EditTextDataArray) {
            ET.setVisibility(editTextVisibality);
        }

        for (TextView TV : TextDataArray) {
            TV.setVisibility(textVisibality);
            if (TV.getId()== R.id.NameTextV && textVisibality == View.GONE)
                TV.setVisibility(View.INVISIBLE);

        }


    }


    public void goToMedicalAtempt(View view) {
        if (EDIT_MODE)
            onOffEditModePrivate();
        else
            refresh();
        if (dataIsLegal()) {
            goTo(MedicalRecords.class);
        }
    }

    private boolean dataIsLegal() {
        return checkData() == 0;
    }

    private int checkData() {
        //TODO 0-good 1-problem in 1 2- probleo in 2 3-...
        return 0;
    }

    public void goToHomeAtempt(View view) {
        if (EDIT_MODE)
            onOffEditModePrivate();
        else
            refresh();

        if (dataIsLegal()) {
            goTo(homeScreen.class);
        }
    }

    private void goTo(Class S) {
        Intent intent = new Intent(this, S);
        startActivity(intent);
    }


}
