package com.example.sembi.logingui;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class signUp extends AppCompatActivity {

    EditText usernameEditT, passwordEditT, checkPasswordEditT;
    Button signUpBtn;
    TextView comment;

    String usrName;
    int passA, passB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        usernameEditT = findViewById(R.id.emailEditT);
        passwordEditT = findViewById(R.id.passEditT);
        checkPasswordEditT = findViewById(R.id.reEnterPassEditT);
        signUpBtn = findViewById(R.id.signUpBtn);
        comment = findViewById(R.id.commentTextV);


        setData();
    }



    private void setData(){
        usrName = usernameEditT.getText().toString();
        boolean flag = false;

        if(isLegalPassword(passwordEditT.getText().toString(),6))
        {
            passA = Integer.parseInt(passwordEditT.getText().toString());
        } else {flag = true;}
        if (isLegalPassword(checkPasswordEditT.getText().toString(),6)) {
            passB = Integer.valueOf(checkPasswordEditT.getText().toString());
        } else if (flag) {
                passA = passB = -1;

        }
    }

    private boolean isLegalPassword(String pass, int length){

        if (pass.length()!= length)
            return false;



        for (int i = 0; i < pass.length(); i++){
            if( (int) (pass.charAt(i)) < 48 || (int) (pass.charAt(i)) > 57 ){
                return false;
            }
        }

        return true;

    }

    public void setETColor(int c, int hc){
        passwordEditT.setHintTextColor(hc);
        checkPasswordEditT.setHintTextColor(hc);
        usernameEditT.setHintTextColor(hc);

        passwordEditT.setTextColor(c);
        checkPasswordEditT.setTextColor(c);
        usernameEditT.setTextColor(c);
    }

    //trying to sign up
    //options:
    //1. sign up will procceed
    //2. a message will go back and ask the user for different sign up details.

    //TODO in while time it is checking in data base, change color to grey.
    public void signUpAtempt(View view){
        setData();

        setETColor(Color.BLACK, getColor(R.color.grey));

        signUp();
    }

    private void signUp(){
        comment.setVisibility(View.INVISIBLE);

        Boolean boolAttempt = false;


        int usrLgl = usernameLegal(usernameEditT.getText().toString());
        if (usrLgl != 0) {
            data_not_proper_message_generator(usrLgl);
        }
        else {
            int PM = passMatch(passA, passB);

            if (PM != 0) {
                data_not_proper_message_generator(PM);
            } else {

                int dataAvailability = checkDataAvalabilty(usrName, passA);

                if (dataAvailability == 0) {
                    Profile.EDIT_MODE = true;
                    Intent intent = new Intent(this, Profile.class);
                    startActivity(intent);

                    boolAttempt = true;

                } else if (dataAvailability == 1) {
                    data_not_proper_message_generator(1);
                } else {
                    data_not_proper_message_generator(0);
                }
            }
        }

        if(!boolAttempt)
            comment.setVisibility(View.VISIBLE);
    }


    private int usernameLegal(String usrName){
        boolean flag = true;
        String temp = usrName;

        for (int i = 0;flag && i < temp.length(); i++){
            if (temp.charAt(i)==' ')
                return 4;
            if (temp.charAt(i)=='@'){
                flag = false;
                temp = temp.substring(i+1);
                if (i == 0)
                    return 4;
            }
        }

        if (flag)
            return 4;

        flag = true;
        for (int i = 0;flag && i < temp.length(); i++){
            if (temp.charAt(i)==' ')
                return 4;
            if (temp.charAt(i)=='.'){
                flag = false;
                temp = temp.substring(i+1);
                if (i == 0)
                    return 4;
            }
        }

        if (flag)
            return 4;

        int i;
        for (i = 0; i < temp.length(); i++){
            if (temp.charAt(i)==' ')
                return 4;
        }
        if (i==0) {
            return 4;
        }




        return 0;
    }

    //0-user created
    //1-username exists
    //2-password not proper
    //3-passwords not match
    //4-username not proper
    public void data_not_proper_message_generator(int message){

        EditText[] editTextsArray = {usernameEditT,passwordEditT,checkPasswordEditT,usernameEditT};
        String[] messagegArray = {getString(R.string.eror_in_system), getString(R.string.user_taken),
                getString(R.string.pass_not_proper), getString(R.string.pass_not_match),
                getString(R.string.user_not_proper)};

        if (message == 0) {
            Toast.makeText(this, messagegArray[message], Toast.LENGTH_LONG).show();
            return;
        }
        showErorInSignUp(editTextsArray[message-1]); //1 because there is not editText for message = 0;
        comment.setText(messagegArray[message]);


    }

    private void showErorInSignUp(EditText t){
        changeColor(t, Color.RED);
    }

    private void changeColor(EditText t, int color){
        t.setTextColor(color);
        t.setHintTextColor(color);
    }


    //0-user created
    //1-username exists
    //2-password not proper
    //3-passwords not match
    //4-username not proper
    private int checkDataAvalabilty(String user, int pass){

        //TODO make conection to data base

        return 0;
    }


    //checks if the passwords matches.
    //2 - pass not legal
    //3 - pass not match
    //0 - pass good.
    private int passMatch(int passA, int passB){
        if (passA == -1)
            return 2;
        if (passA != passB)
            return 3;

        return 0;
    }
}
