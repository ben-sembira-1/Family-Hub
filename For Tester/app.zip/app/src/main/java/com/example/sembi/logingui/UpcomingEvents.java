package com.example.sembi.logingui;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class UpcomingEvents extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upcoming_events);


    }
}
