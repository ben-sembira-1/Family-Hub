package com.example.sembi.logingui;

public class ProfileTest {
}